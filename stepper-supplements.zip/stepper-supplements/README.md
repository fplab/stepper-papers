# Practical Algebraic Stepping with Scoped Filters

Supplementary material for the ECOOP 2027 submission.

| Directory | Contents | Entry point |
| --- | --- | --- |
| `agda/` | Calculus and mechanized preservation, progress, and simulation proofs. | `make agda` |
| `stepper/` | OCaml reference implementation: source, tests, and a prebuilt interactive browser app. | `make stepper` |
| `hazel/` | Prebuilt Hazel environment with the scoped filter stepper. | `make hazel` |

Both browser apps need Python 3 (or another static HTTP server) and a modern
browser. No OCaml installation is needed to try them. Agda is needed only for
checking the proofs. See each directory's README for details.

## Try the browser apps

```sh
make serve
```

This starts both apps:

- Hazel: <http://localhost:8000/>
- OCaml reference stepper: <http://localhost:8001/>

Use `Ctrl-C` to stop the servers. Run only one app with `make hazel` or
`make stepper`. To choose different ports:

```sh
make serve HAZEL_PORT=9000 STEPPER_PORT=9001
```

Without Make, run these in separate terminals:

```sh
python3 -m http.server 8000 --bind 127.0.0.1 --directory hazel
python3 -m http.server 8001 --bind 127.0.0.1 --directory stepper/web/dist
```

Open each app over HTTP, rather than opening `index.html` as a local file.
Both use Web Workers. Hazel's initial load may take a few seconds.

## Try the reference stepper

Enter this example in the editor at <http://localhost:8001/>:

```
debug eval(1 + 2 + 3 + 4) in
debug stop(3 + 3 + 4) in
1 + 2 + 3 + 4
```

Evaluation updates as you type. The first addition, `1 + 2`, reduces silently;
`3 + 3` is highlighted in blue inside its surrounding expression. Click it to
continue to the final value `10`. The selected reduction appears in the history.

Try `(1 + 2) + (3 + 4)` to see independently selectable redexes. Show Residue
controls the display of internal residues. Editing the program starts a fresh
trace and cancels pending evaluation. The editor saves its text in local storage.

Source, build instructions, and tests are in [`stepper/README.md`](stepper/README.md).
The optional command-line interface can be built from the same source.
Instructions for the full Hazel environment are in [`hazel/README.md`](hazel/README.md).

## Check the mechanization

With Agda 2.6.4.1 and agda-stdlib 2.0 registered as a default library:

```sh
make agda
```

This runs `agda --safe All.agda` in `agda/`. The README there maps the paper's
results to the corresponding declarations.
