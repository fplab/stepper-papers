# Hazel browser demo

This is a prebuilt copy of Hazel with the scoped filter stepper described in
the paper. The application and evaluator are included as JavaScript; no OCaml
toolchain is needed to run this demo.

## Run

From the top-level supplementary-material directory, run `make serve`, then
open <http://localhost:8000/>. Alternatively, from this directory:

```sh
python3 -m http.server 8000 --bind 127.0.0.1
```

Use a modern browser with JavaScript and Web Workers enabled. Open the HTTP
address, rather than double-clicking `index.html`. This is an unminified build,
so the initial load may take a few seconds.

## Try the stepper

Open a scratch editor and enter the addition example from the paper:

```
debug eval(1 + 2 + 3 + 4) in
debug stop(3 + 3 + 4) in
1 + 2 + 3 + 4
```

Open the stepper panel. The `eval` filter hides the first addition. The `stop`
filter reveals the next addition, `3 + 3`; selecting it lets the remaining
evaluation continue to `10`.

| Filter | Action | Persistence |
| --- | --- | --- |
| `eval(p)` | Skip | Persistent |
| `step(p)` | Step | Persistent |
| `hide(p)` | Skip | One-shot |
| `stop(p)` | Step | One-shot |

Patterns include `$e` for any expression and `$v` for a value, as well as
structural patterns such as `$v + $v`. `$v` does not match a bound variable
merely because it occurs inside a function body.

Hazel retains its own evaluation strategy and language extensions. In
particular, matching treats its internal recursive-function wrapper as
transparent. The smaller calculus is mechanized separately in `../agda/`.

## Files and local data

`index.html`, `hazel.js`, `worker.js`, and `bundled.js` form the application;
`style.css`, `style/`, and `img/` contain its visual assets. Only the prebuilt
Hazel application is supplied here. The OCaml reference implementation's
source is in `../stepper/`.

Evaluation runs in the browser. Hazel stores editor state in the browser's
local storage and IndexedDB. The page also requests its Material Icons font
from Google Fonts; other Hazel features can use external services. The local
stepper does not require configuring an account or an external evaluator.

Build-specific branch names, commit and pull-request identifiers, source maps,
and local compiler paths have been removed or anonymized for review. License
notices are included in `LICENSE` and `licenses/`.
