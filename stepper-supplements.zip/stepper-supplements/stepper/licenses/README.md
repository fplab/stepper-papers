# Third-party notices

The prebuilt browser app contains OCaml and Melange runtime code, Reason React,
web API bindings, React, and CodeMirror. Their notices are included verbatim.
The PPrint license is retained in `../web/vendor/pprint/LICENSE`.

The `npm/` directory records the exact installed runtime dependency closure from
the supplied lockfile, including each package's original license and metadata.

| Package | Version | Declared license |
| --- | --- | --- |
| @babel/runtime | 7.24.4 | MIT |
| @codemirror/autocomplete | 6.16.0 | MIT |
| @codemirror/commands | 6.6.0 | MIT |
| @codemirror/language | 6.10.2 | MIT |
| @codemirror/lint | 6.5.0 | MIT |
| @codemirror/search | 6.5.6 | MIT |
| @codemirror/state | 6.4.1 | MIT |
| @codemirror/theme-one-dark | 6.1.2 | MIT |
| @codemirror/view | 6.30.0 | MIT |
| @lezer/common | 1.2.1 | MIT |
| @lezer/highlight | 1.2.0 | MIT |
| @lezer/lr | 1.4.2 | MIT |
| @uiw/codemirror-extensions-basic-setup | 4.23.0 | MIT |
| @uiw/react-codemirror | 4.23.0 | MIT |
| codemirror | 6.0.1 | MIT |
| crelt | 1.0.6 | MIT |
| js-tokens | 4.0.0 | MIT |
| loose-envify | 1.4.0 | MIT |
| react | 18.3.1 | MIT |
| react-dom | 18.3.1 | MIT |
| regenerator-runtime | 0.14.1 | MIT |
| scheduler | 0.23.2 | MIT |
| style-mod | 4.1.2 | MIT |
| w3c-keyname | 2.2.8 | MIT |

The two UIW npm archives omit the license file; their shared MIT notice was
retrieved verbatim from the matching upstream release:
<https://github.com/uiwjs/react-codemirror/blob/v4.23.0/LICENSE>.
