# OCaml reference implementation

This package contains the OCaml evaluator, its native tests, and a prebuilt
Hazel Mini Stepper browser app using Melange and Reason React. The browser and
command-line interfaces share the same evaluator sources in `lib/`.

## Try the browser app

From this directory:

```sh
make -C web serve
```

Open <http://localhost:8001/>. No OCaml or JavaScript build tools are needed.
Without Make, run:

```sh
python3 -m http.server 8001 --bind 127.0.0.1 --directory web/dist
```

Enter a program in the editor; evaluation updates as you type. Silent reductions
run automatically. Click a blue redex within the displayed expression to take a
visible step; the chosen expression is added to the history. Show Residue
controls the display of internal residues. Editing the program starts a fresh
trace and cancels pending evaluation. The browser saves the editor text in local
storage. The obsolete Optimize switch has been removed because residue management
is part of decomposition.

For the example in Section 3.2, enter:

```
debug eval(1 + 2 + 3 + 4) in
debug stop(3 + 3 + 4) in
1 + 2 + 3 + 4
```

The first addition is silent. Click the blue `3 + 3` to continue to `10`.
The app must be served over HTTP so its module worker can load.

## Build from source

The tested toolchain is OCaml 5.2.0, Dune 3.23.1, Melange 4.0.1-52,
Reason React 0.14.1, and pnpm 9.4.0. The original JavaScript dependencies are
fixed by `web/pnpm-lock.yaml`. To create a separate switch and rebuild:

```sh
cd web
opam switch create . ocaml-base-compiler.5.2.0
eval "$(opam env --switch=. --set-switch)"
make deps
make
make serve
```

If a compatible switch is already active, omit the switch creation and activation.
`make dev` starts the Vite development server; production output is in `web/dist/`.
See [`web/README.md`](web/README.md) for details.

The library in `lib/` compiles directly for native OCaml and Melange. No second
copy of the evaluator is maintained. From this directory, using the switch above,
run the existing native tests or the optional command-line interface:

```sh
opam install --switch=web . --deps-only --with-test
opam exec --switch=web -- dune build
opam exec --switch=web -- dune runtest
opam exec --switch=web -- dune exec bin/main.exe -- --mode trace examples/section-3-2.stepper
```

The native suite has 31 regression tests and 14 generated properties. The trace
command ends at `10`. Its modes are `step` (silent reductions followed by visible
choices), `decompose` (immediate candidates), and `trace` (choose the leftmost
silent candidate, otherwise the leftmost visible candidate). Input can be a file,
standard input, or `--expr PROGRAM`; `--limit N` bounds automatic transitions.

## Language and files

| Keyword | Action | Persistence |
| --- | --- | --- |
| `hide(p)` | skip | one-shot |
| `eval(p)` | skip | persistent |
| `stop(p)` | step | one-shot |
| `step(p)` | step | persistent |

Patterns include `$e`, `$v`, and structural patterns under `fun` and `fix`.
`$v` follows the value judgment everywhere: integers, booleans, and functions
match; variables do not. Structural matching compares bound variables up to
alpha-equivalence and ignores filter and residue wrappers.

The executable extends the paper's calculus with booleans, equality,
subtraction, multiplication, conditionals, and `let`/`let rec` syntax.
Integers are signed 32-bit values with wrapping arithmetic. There is no static
typechecker; ill-typed input can produce evaluation errors.

| Path | Contents |
| --- | --- |
| `lib/` | Shared syntax, parser, matching, substitution, contexts, and stepping. |
| `web/` | Reason React interface, worker, display code, and build configuration. |
| `web/dist/` | Prebuilt browser app. |
| `bin/main.ml` | Optional command-line entry point. |
| `test/` | Existing native regression and property tests. |
| `examples/` | Command-line example programs. |
| `licenses/` | Notices for bundled third-party code. |

The implementation license is in `LICENSE`; the vendored printer retains its
license in `web/vendor/pprint/LICENSE`.
